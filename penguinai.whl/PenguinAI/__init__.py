import requests
def send(prompt, model="gpt-4o"):
    payload = {
        "model": model,
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }
    response = requests.post("https://reverse.mubi.tech/v1/chat/completions", json=payload).json()
    return response['choices'][0]['message']['content']
